
define(['lib/class', 'lib/underscore.min', 'lib/stacktrace', 'util'], function() {
    require(["main"]);
});